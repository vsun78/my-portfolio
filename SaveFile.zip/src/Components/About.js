// About.js
import { useState } from 'react';
// FaultyTerminal is provided globally from the header.  No need to import it here.

function About() {
  const [activeTab, setActiveTab] = useState('experience');

  const handleTabClick = (tabName) => {
    setActiveTab(tabName);
  };

  return (
    <div id="about" style={{ position: 'relative' }}>
      <div className="container">
        <div className="row">
          <div className="about-col-1">
            {/* in this column, we add images */}
            <img src="/images/VictorPFP.JPG" alt="Victor" />
          </div>

          <div className="about-col-2">
            {/* in this column we add text */}
            <h1 className="sub-title">About Me</h1>
            <p>
              currently working as a full stack developer & IT intern @ McAsphalt and studying SWE @ uwestern.
            </p>

            <div className="tab-titles">
              <p
                className={`tab-links ${activeTab === 'experience' ? 'active-link' : ''}`}
                onClick={() => handleTabClick('experience')}
              >
                Experience
              </p>
              <p
                className={`tab-links ${activeTab === 'education' ? 'active-link' : ''}`}
                onClick={() => handleTabClick('education')}
              >
                Education
              </p>
            </div>

            <div className={`tab-contents ${activeTab === 'experience' ? 'active-tab' : ''}`} id="experience">
              <ul>
                <li>
                  <span>Software Development</span><br />
                  I am a third year SWE + CO-OP student at Western University. I have practical experience developing
                  using Java, JavaScript, Python, C#, SQL, TypeScript, HTML/CSS with frameworks and tools such as
                  React, Spring Boot, Git, Postman, Figma, PostgreSQL, REST API, Netlify, and Railway.
                </li>
                <li>
                  <span>Machine Learning</span><br />
                  • Used Python, TensorFlow, and YOLOV8 to train a deep learning model to detect early-stage melanoma
                  from skin lesion images using custom-labeled training datasets.<br />
                  • Currently working as a Lead Developer to train AI models to predict sales, cost, and consumption
                  patterns for McAsphalt Industries Limited.
                </li>
                <li>
                  <span>Leadership</span><br />
                  • Orchestrated the development of an RPG Game with a team of six and showed strong communication and
                  leadership skills by guiding the group throughout the entire process. <br />
                  • The RPG game was built using C# and Unity, implementing core gameplay systems including character
                  movement, level progression, and challenging boss fights. <br />
                  • Created an engaging player experience with a shop and inventory system, strategic combat, puzzles,
                  and thoughtful game balance.
                </li>
              </ul>
            </div>

            <div className={`tab-contents ${activeTab === 'education' ? 'active-tab' : ''}`} id="education">
              <ul>
                <li>
                  <span>Western University</span><br />
                  Software Engineering
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;